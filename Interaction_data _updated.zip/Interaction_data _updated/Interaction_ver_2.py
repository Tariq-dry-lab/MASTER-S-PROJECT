import os

# Step 1: Extract table from .log file
def table_extraction(input_file1, output_file1):
    with open(input_file1, 'r') as infile, open(output_file1, 'w') as outfile:
        for line in infile:
            if "E(2) E(NL)-E(L) F(L,NL)" in line:
                outfile.write(line)
                break
        for line in infile:
            if "NATURAL BOND ORBITALS (Summary):" in line:
                break
            if "RY" in line:
                continue
            outfile.write(line)

def clean_spacing(line): 
    return " ".join(line.split())

def classify_interaction(line):
    if "LP ( 1)" in line and "BD*( 1)" in line:
        return "n sigma*"
    elif "LP ( 2)" in line and "BD*( 1)" in line:
        return "n sigma*"
    elif "LP ( 1)" in line and ("BD*( 2)" in line or "BD*( 3)" in line):
        return "n pi*"
    elif "LP ( 2)" in line and ("BD*( 2)" in line or "BD*( 3)" in line):
        return "n pi*"
    elif "BD ( 1)" in line and "BD*( 1)" in line:
        return "sigma sigma*"
    elif "BD ( 1)" in line and ("BD*( 2)" in line or "BD*( 3)" in line):
        return "sigma pi*"
    elif "BD ( 2)" in line and "BD*( 1)" in line:
        return "pi sigma*"
    elif "BD ( 2)" in line and ("BD*( 2)" in line or "BD*( 3)" in line):
        return "pi pi*"
    else:
        return None

def remove_dashes(text):
    return text.replace('-', '')

def process_file(output_file1, output_file2):
    classifications = {
        "n sigma*": [],
        "n pi*": [],
        "sigma sigma*": [],
        "sigma pi*": [],
        "pi sigma*": [],
        "pi pi*": []
    }

    with open(output_file1, 'r') as infile:
        lines = infile.readlines()[5:]  
        cleaned_lines = [clean_spacing(line) for line in lines]

        for line in cleaned_lines:
            classify = classify_interaction(line)
            if classify in classifications:
                classifications[classify].append(remove_dashes(line.strip()))

    with open(output_file2, 'w') as outfile:
        for category, interactions in classifications.items():
            outfile.write(f"{category}: {len(interactions)} interactions\n")
            for entry in interactions:
                outfile.write(entry + "\n")
            outfile.write("\n\n")

def parse_pdb_connectivity(pdb_file):
    connectivity = {}
    atom_info = {}

    with open(pdb_file, 'r') as f:
        for line in f:
            if line.startswith(("ATOM", "HETATM")):
                atom_id = line[6:11].strip()
                atom_symbol = line[76:78].strip()
                atom_info[atom_id] = f"{atom_symbol} {atom_id}"
            elif line.startswith("CONECT"):
                parts = line.split()
                atom_id = parts[1]
                bonded_ids = parts[2:]
                if atom_id in atom_info:
                    atom_key = atom_info[atom_id]
                    connectivity.setdefault(atom_key, [])
                    for bonded_id in bonded_ids:
                        if bonded_id in atom_info:
                            connectivity[atom_key].append(atom_info[bonded_id])
    return connectivity

def find_shortest_path(connectivity, start_atoms, end_atoms):
    queue = [(atom, [atom]) for atom in start_atoms if atom in connectivity]
    visited = set()
    idx = 0

    while idx < len(queue):
        current_atom, path = queue[idx]
        idx += 1

        if current_atom in end_atoms:
            return path

        if current_atom not in visited:
            visited.add(current_atom)
            for neighbor in connectivity.get(current_atom, []):
                if neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))

    return None

def process_classification_file(pdb_file, output_file2, output_file3):
    connectivity = parse_pdb_connectivity(pdb_file)

    with open(output_file2, 'r') as infile, open(output_file3, 'w') as outfile:
        for line in infile:
            parts = line.strip().split()
            bond_count = ""
            label = ""

            if len(parts) == 16:
                start_atoms = {f"{parts[4]} {parts[5]}"}
                end_atoms = {f"{parts[9]} {parts[10]}", f"{parts[11]} {parts[12]}"}
            elif len(parts) == 18:
                start_atoms = {f"{parts[4]} {parts[5]}", f"{parts[6]} {parts[7]}"}
                end_atoms = {f"{parts[11]} {parts[12]}", f"{parts[13]} {parts[14]}"}
            else:
                outfile.write(line)
                continue

            path = find_shortest_path(connectivity, start_atoms, end_atoms)
            if path:
                bond_count = str(len(path) - 1)
                label = "L" if len(path) - 1 >= 3 else "S"
                line = line.strip() + f" {bond_count} {label}\n"
            else:
                line = line.strip() + "\n"

            outfile.write(line)

def filter_L(output_file3, output_file4):
    with open(output_file3, 'r') as infile:
        lines = infile.readlines()

    output_lines = []
    category_counts = {}
    current_category = None

    for line in lines:
        stripped = line.strip()
        if "interactions" in stripped:
            current_category = stripped.split(':')[0].strip()
            category_counts[current_category] = []
            output_lines.append((line, current_category))
        elif stripped == "":
            output_lines.append((line, None))
        elif current_category:
            parts = stripped.split()
            if parts and parts[-1] == 'L':
                category_counts[current_category].append(stripped)
                output_lines.append((line, None))
        else:
            output_lines.append((line, None))

    with open(output_file4, 'w') as outfile:
        for line, category in output_lines:
            if category:
                count = len(category_counts[category])
                outfile.write(f"{count} interactions {category}:\n")
            else:
                outfile.write(line)


def energy_totals(file_name):
    category_energy = {}
    lines = []
    current_category = None

    with open(file_name, 'r') as file:
        for line in file:
            stripped = line.strip()
            if 'interactions' in stripped:
                current_category = stripped.split(' interactions')[0].strip()
                category_energy[current_category] = 0.0
                lines.append((line, current_category))
            elif stripped == '':
                lines.append((line, None))
            else:
                parts = stripped.split()
                try:
                    if len(parts) == 18:
                        energy = float(parts[13])
                        category_energy[current_category] += energy
                    elif len(parts) == 20:
                        energy = float(parts[15])
                        category_energy[current_category] += energy
                except:
                    pass
                lines.append((line, None))

    with open(file_name, 'w') as file:
        for line, category in lines:
            if category:
                energy = category_energy[category]
                new_line = f"{energy:.3f} kcal/mol {line} \n"
                file.write(new_line)
            else:
                file.write(line)


log_file = input("Enter the .log file name (e.g., NMe2_P1.log): ").strip()
pdb_file = input("Enter the .pdb file name (e.g., P1.pdb): ").strip()
base_name = os.path.splitext(os.path.basename(log_file))[0]

output_file1 = f"{base_name}_perturbation.txt"
output_file2 = f"{base_name}_classification.txt"
output_file3 = f"{base_name}_bondsep.txt"
output_file4 = f"{base_name}_L.txt"


table_extraction(log_file, output_file1)
print(f"1. Perturbation data saved to {output_file1}")

process_file(output_file1, output_file2)
print(f"2. Classification saved to {output_file2}")

process_classification_file(pdb_file, output_file2, output_file3)
print(f"3. Bond separation saved to {output_file3}")

filter_L(output_file3, output_file4)
print(f"4. Long-range interactions saved to {output_file4}")
energy_totals(output_file4)
print(f"5. Energy totals added in {output_file4}\nAll steps completed successfully.")

